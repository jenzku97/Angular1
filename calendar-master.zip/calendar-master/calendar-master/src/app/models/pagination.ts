export interface PaginationData {
  limit: number;
  totalCount: number;
  offset: number;
}
