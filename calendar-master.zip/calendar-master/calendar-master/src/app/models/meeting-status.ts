export interface MeetingStatus {
  id: number;
  name: string;
}
