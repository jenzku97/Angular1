export interface DeclineReason {
  id: number;
  name: string;
}
